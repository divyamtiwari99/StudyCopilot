import {
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";

import { queryKeys } from "@/lib/queryKeys";

import {
  generateKnowledgeGraph,
} from "@/features/knowledge-graph/services/knowledge-graph.service";

export function useGenerateKnowledgeGraph() {
  const queryClient =
    useQueryClient();

  return useMutation({
    mutationFn:
      generateKnowledgeGraph,

    onSuccess: (
      _,
      contentId,
    ) => {
      queryClient.invalidateQueries({
        queryKey:
          queryKeys.knowledgeGraph(
            contentId,
          ),
      });

      queryClient.invalidateQueries({
        queryKey:
          queryKeys.document(
            contentId,
          ),
      });
    },
  });
}