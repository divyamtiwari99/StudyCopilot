import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  type Edge,
  type Node,
} from "@xyflow/react";

import "@xyflow/react/dist/style.css";

interface GraphNode {
  id: string;
  label: string;
  category: string;
  description: string;
}

interface GraphEdge {
  source: string;
  target: string;
  relationship: string;
}

interface Props {
  graph: {
    nodes: GraphNode[];
    edges: GraphEdge[];
  };
}

export default function KnowledgeGraphViewer({
  graph,
}: Props) {
  const nodes: Node[] =
    graph.nodes.map(
      (node, index) => ({
        id: node.id,

        position: {
          x: (index % 5) * 260,
          y: Math.floor(index / 5) * 180,
        },

        data: {
          label: (
            <div className="space-y-1">

              <div className="font-semibold">
                {node.label}
              </div>

              <div className="text-xs text-zinc-400">
                {node.category}
              </div>

            </div>
          ),
        },

        style: {
          borderRadius: 16,

          padding: 10,

          border:
            "1px solid rgba(34,211,238,.4)",

          background: "#09111f",

          color: "white",

          width: 180,
        },
      })
    );

  const edges: Edge[] =
    graph.edges.map((edge) => ({
      id: `${edge.source}-${edge.target}`,

      source: edge.source,

      target: edge.target,

      label:
        edge.relationship,

      animated: true,
    }));

  return (
    <div className="h-[750px] rounded-3xl overflow-hidden border border-white/10">

      <ReactFlow
        fitView
        nodes={nodes}
        edges={edges}
      >

        <Background />

        <MiniMap />

        <Controls />

      </ReactFlow>

    </div>
  );
}