import {
  CalendarDays,
  CheckCircle2,
  Clock3,
} from "lucide-react";

interface PlannerTask {
  title: string;

  estimatedTime?: string;
}

interface PlannerDay {
  day: number;

  title: string;

  description?: string;

  tasks: PlannerTask[];
}

interface PlannerTimelineProps {
  days: PlannerDay[];
}

export default function PlannerTimeline({
  days,
}: PlannerTimelineProps) {
  return (
    <div className="space-y-8">

      {days.map((day) => (

        <section
          key={day.day}
          className="rounded-3xl border border-white/10 bg-white/[0.04] p-8 backdrop-blur-xl"
        >

          <div className="mb-6 flex items-center justify-between">

            <div>

              <div className="inline-flex items-center gap-2 rounded-full border border-cyan-500/20 bg-cyan-500/10 px-4 py-2 text-sm text-cyan-300">

                <CalendarDays size={16} />

                Day {day.day}

              </div>

              <h2 className="mt-4 text-2xl font-bold text-white">
                {day.title}
              </h2>

              {day.description && (

                <p className="mt-3 text-zinc-400">
                  {day.description}
                </p>

              )}

            </div>

          </div>

          <div className="space-y-4">

            {day.tasks.map(
              (task, index) => (

                <div
                  key={index}
                  className="flex items-center justify-between rounded-2xl border border-white/10 bg-[#0b1220] p-5"
                >

                  <div className="flex items-center gap-4">

                    <CheckCircle2
                      size={22}
                      className="text-cyan-400"
                    />

                    <span className="text-white">
                      {task.title}
                    </span>

                  </div>

                  {task.estimatedTime && (

                    <div className="flex items-center gap-2 text-sm text-zinc-400">

                      <Clock3 size={15} />

                      {task.estimatedTime}

                    </div>

                  )}

                </div>

              ),
            )}

          </div>

        </section>

      ))}

    </div>
  );
}