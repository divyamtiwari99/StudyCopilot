import { useParams } from "react-router-dom";

import QuizViewer from "@/features/quiz/components/QuizViewer";
import { useQuiz } from "@/features/quiz/hooks/useQuiz";

export default function QuizPage() {
  const { contentId } = useParams();

  const {
    data,
    isLoading,
    isError,
  } = useQuiz(contentId);

  if (isLoading) {
    return (
      <div className="flex h-80 items-center justify-center">
        <p className="text-zinc-400">
          Loading quiz...
        </p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex h-80 items-center justify-center">
        <p className="text-red-400">
          Failed to load quiz.
        </p>
      </div>
    );
  }

  if (
    !data ||
    !Array.isArray(data.json) ||
    data.json.length === 0
  ) {
    return (
      <div className="flex h-80 flex-col items-center justify-center space-y-4 rounded-3xl border border-dashed border-white/10">
        <h2 className="text-2xl font-semibold text-white">
          No Quiz Found
        </h2>

        <p className="max-w-md text-center text-zinc-400">
          Generate a quiz from the AI Command Center
          above to start practicing.
        </p>
      </div>
    );
  }

  return (
    <QuizViewer
      questions={data.json}
    />
  );
}